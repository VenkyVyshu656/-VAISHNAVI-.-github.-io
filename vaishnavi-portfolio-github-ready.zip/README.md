# VAISHNAVI MANDEM — Personal Portfolio

Personal portfolio website for **VAISHNAVI MANDEM**, B.Tech CSE Student & Developer and Aspiring Forward Deployed Engineer (FDE).

## Website
This repository is designed for GitHub Pages.

## Main sections
- About
- Skills
- Projects
- Certifications
- Participation & Achievements
- Contact

## Tech
- HTML5
- CSS3
- Responsive design
- CSS animations/transitions

## Deploy with GitHub Pages
1. Open the repository on GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select **main** and **/ (root)**.
5. Save.
6. After deployment, GitHub will provide the live website URL.

## Personal links
GitHub: https://github.com/VenkyVyshu656
LinkedIn: https://www.linkedin.com/in/vaishnavi-mandem-1206473a7/
